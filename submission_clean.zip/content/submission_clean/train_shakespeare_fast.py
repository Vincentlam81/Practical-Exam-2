
out_dir = 'out-shakespeare-fast'
eval_interval = 100
log_interval = 20
eval_iters = 2
always_save_checkpoint = False
wandb_log = False

dataset = 'shakespeare_char'
gradient_accumulation_steps = 1
batch_size = 8
block_size = 64

n_layer = 2
n_head = 2
n_embd = 32
dropout = 0.2

learning_rate = 1e-3
max_iters = 300
lr_decay_iters = 300
min_lr = 1e-4
beta2 = 0.99
warmup_iters = 20

device = 'cuda'
compile = False
