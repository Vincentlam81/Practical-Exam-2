
out_dir = 'out-shakespeare-step2-slightlylighter'
eval_interval = 500
log_interval = 10
eval_iters = 60
always_save_checkpoint = True

wandb_log = False

dataset = 'shakespeare_char'
gradient_accumulation_steps = 1
batch_size = 48
block_size = 256

n_layer = 6
n_head = 8
n_embd = 224
dropout = 0.2

learning_rate = 1e-3
max_iters = 2500
lr_decay_iters = 2500
min_lr = 1e-4
beta2 = 0.99
warmup_iters = 200

device = 'cuda'
compile = False
