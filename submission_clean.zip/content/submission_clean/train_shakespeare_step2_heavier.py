
out_dir = 'out-shakespeare-step2-heavier'
eval_interval = 500
log_interval = 10
eval_iters = 70
always_save_checkpoint = True

wandb_log = False

dataset = 'shakespeare_char'
gradient_accumulation_steps = 1
batch_size = 48
block_size = 128

n_layer = 7
n_head = 4
n_embd = 224
dropout = 0.2

learning_rate = 1e-3
max_iters = 3500
lr_decay_iters = 3500
min_lr = 1e-4
beta2 = 0.99
warmup_iters = 150

device = 'cuda'
compile = False
