
out_dir = 'out-shakespeare-l7-h4'
eval_interval = 500
log_interval = 10
eval_iters = 50
always_save_checkpoint = True

wandb_log = False

dataset = 'shakespeare_char'
gradient_accumulation_steps = 1
batch_size = 32
block_size = 128

n_layer = 7
n_head = 4
n_embd = 160
dropout = 0.2

learning_rate = 1e-3
max_iters = 2500
lr_decay_iters = 2500
min_lr = 1e-4
beta2 = 0.99
warmup_iters = 100

device = 'cuda'
compile = False
